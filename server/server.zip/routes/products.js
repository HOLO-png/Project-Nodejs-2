const router = require('express').Router();
const auth = require('../middleware/auth.js');
const productsCtrl = require('../controllers/productsCtrl.js');

// get product admin

router.post('/', productsCtrl.createProduct);
router.get('/', productsCtrl.getProducts);
router.put('/:productId', auth, productsCtrl.updateProductLike);
router.get('/search', productsCtrl.searchProduct);
router.get('/:productId', productsCtrl.getProduct);

module.exports = router;
